package com.bit.dicomdw.dcm.exception;

public class MyDcmException extends RuntimeException {
    public MyDcmException(String msg){
        super(msg);
    }
}
