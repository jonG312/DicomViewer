package com.bit.dicomdw.dcm.transform;

import com.bit.dicomdw.dcm.img.MyImg;

public interface MyTransform {
    MyImg work(MyImg img);
}
