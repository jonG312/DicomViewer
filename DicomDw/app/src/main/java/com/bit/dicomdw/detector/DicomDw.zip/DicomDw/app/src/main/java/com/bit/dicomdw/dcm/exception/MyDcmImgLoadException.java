package com.bit.dicomdw.dcm.exception;

public class MyDcmImgLoadException extends MyDcmException {
    public MyDcmImgLoadException(String msg){super(msg);}
}
