package com.bit.dicomdw.dcm.exception;

public class MyDcmTagReadException extends MyDcmException {
    public MyDcmTagReadException(String msg){
        super(msg);
    }
}
